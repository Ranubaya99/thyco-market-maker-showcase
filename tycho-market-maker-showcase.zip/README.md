# Tycho Market Maker Showcase

This project demonstrates how to build an on-chain market maker using the Tycho ecosystem.

## Features
- Monitor token prices and inventory
- Simulate and calculate trading strategies
- Execute trades on DEXs via Tycho Execution
- Integrate with Tycho Protocol SDK
- Real-time dashboard (optional)

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/tycho-market-maker-showcase.git
cd tycho-market-maker-showcase
pip install -r requirements.txt
```

## Run

```bash
python market_maker/main.py
```

## License
MIT
